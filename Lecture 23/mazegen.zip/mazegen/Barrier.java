package mazegen;

public interface Barrier
{
    public int getVal();
}
