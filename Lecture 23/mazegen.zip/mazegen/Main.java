package mazegen;

import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

public class Main
{
    public static void main(String[] args)
    {
        boolean backwardIsStep = true;
        boolean drawActive = true;
        long millisecond_period = 50;

        final DfsMazeGenerator gen = new DfsMazeGenerator(10, 10, backwardIsStep);

        final JFrame frame = new JFrame();
        final JPanel panel = new MazePanel(gen, drawActive, 400, 400);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);

        final ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor();
        ex.scheduleAtFixedRate(new Runnable()
        {
            public void run()
            {
                if(gen.SimulationDone())
                    ex.shutdown();
                else
                {
		    final Object lock = new Object();

                    gen.SimulateForward();
                    panel.repaint();

		    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            synchronized (lock) {
                                lock.notify();
                            }
                        }
                    });

                    try {
                         synchronized (lock) {
                             lock.wait();
                         }
                    } catch (InterruptedException iex) {
                         System.exit(-1);
                    }
                }
            }

        }, 0, millisecond_period, TimeUnit.MILLISECONDS);
    }

}
